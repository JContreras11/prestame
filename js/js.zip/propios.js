

/** FUNCIONES PARA SMARTSOL ****/


    function limpiaForm(miForm) {
// recorremos todos los campos que tiene el formulario
$('#'+miForm).find(':input').each(function(){
  var type = this.type, tag = this.tagName.toLowerCase();
  if (type == 'text' || type == 'password' || tag == 'textarea')
    this.value = '';
  else if (type == 'checkbox' || type == 'radio')
    this.checked = false;
  else if (tag == 'select')
    this.selectedIndex = 0;
})

}


Number.prototype.padLeft = function(base,chr){
   var  len = (String(base || 10).length - String(this).length)+1;
   return len > 0? new Array(len).join(chr || '0')+this : this;
}


function horaActual() { // YYYY/MM/DD hh:mm:ss
    var d = new Date();
    dformat = [d.getFullYear(),(d.getMonth()+1).padLeft(), d.getDate().padLeft()].join('/')+
                ' ' +
              [ d.getHours().padLeft(),
                d.getMinutes().padLeft(),
                d.getSeconds().padLeft()].join(':');
return dformat;
                  }
